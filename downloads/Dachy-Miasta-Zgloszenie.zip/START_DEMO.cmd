@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Zainstaluj Node.js 22 lub nowszy z https://nodejs.org/
  pause
  exit /b 1
)
echo Otworz http://127.0.0.1:4173/ w przegladarce. Ctrl+C zatrzymuje serwer.
node start.mjs
pause
