import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const args = process.argv.slice(2);
const portAt = args.indexOf('--port');
const port = portAt >= 0 ? Number(args[portAt + 1]) : 4173;
if (!Number.isInteger(port) || port < 1 || port > 65535) throw new RangeError('Port musi być liczbą od 1 do 65535.');
const rootAt = args.indexOf('--root');
if (rootAt >= 0 && !args[rootAt + 1]) throw new Error('Brak katalogu po --root.');
const root = rootAt >= 0 ? path.resolve(args[rootAt + 1]) : path.resolve(fileURLToPath(new URL('../', import.meta.url)));
const types = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8', '.map': 'application/json', '.geojson': 'application/geo+json', '.svg': 'image/svg+xml', '.png': 'image/png', '.md': 'text/plain; charset=utf-8', '.txt': 'text/plain; charset=utf-8', '.pdf': 'application/pdf', '.woff2': 'font/woff2' };
const server = http.createServer(async (req, res) => {
  try {
    const pathname = decodeURIComponent(new URL(req.url, 'http://localhost').pathname);
    const target = path.resolve(root, '.' + (pathname === '/' ? '/index.html' : pathname));
    if (!target.startsWith(root + path.sep) || !/\.(html|js|css|json|map|geojson|svg|png|md|txt|pdf|woff2)$/.test(target)) {
      res.writeHead(403); res.end('Forbidden'); return;
    }
    const content = await fs.readFile(target);
    res.writeHead(200, { 'Content-Type': types[path.extname(target)] || 'application/octet-stream', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' });
    res.end(content);
  } catch (error) {
    res.writeHead(error.code === 'ENOENT' ? 404 : 500); res.end('Not found');
  }
});
server.listen(port, '127.0.0.1', () => console.log(`Dachy Miasta · Local: http://127.0.0.1:${port}`));
server.on('error', error => {
  console.error(error.code === 'EADDRINUSE' ? `Port ${port} jest zajęty. Użyj --port ${port + 1}.` : error.message);
  process.exitCode = 1;
});
